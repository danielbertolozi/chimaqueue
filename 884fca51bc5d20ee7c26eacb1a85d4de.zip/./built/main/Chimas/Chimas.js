"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const QueueHolder_1 = require("./QueueHolder");
class Chimas {
    constructor() {
        this.queues = new QueueHolder_1.default();
        this.actionsMap = {
            [Actions.new]: this.newQueue.bind(this),
            [Actions.join]: this.join.bind(this),
            [Actions.leave]: this.leave.bind(this),
            [Actions.next]: this.next.bind(this),
            [Actions.who]: this.who.bind(this),
            [Actions.clear]: this.clear.bind(this),
            [Actions.help]: this.help.bind(this)
        };
    }
    execute(action, payload) {
        if (!Actions[action]) {
            return "Action not available.";
        }
        const channelName = payload.channel_name;
        const userName = payload.user_name;
        return this.actionsMap[action](channelName, userName);
    }
    join(channelName, userName) {
        let message;
        try {
            this.queues.get(channelName).add(userName);
            message = `${userName} has joined the queue!`;
        }
        catch (e) {
            message = e.message;
        }
        return message;
    }
    newQueue(channelName) {
        let message;
        try {
            this.queues.create(channelName);
            message = `Queue started for channel ${channelName}`;
        }
        catch (e) {
            message = e.message;
        }
        return message;
    }
    leave(channelName, userName) {
        let message;
        try {
            this.queues.get(name).remove(userName);
            message = `User ${userName} has left the queue.`;
        }
        catch (e) {
            message = e.message;
        }
        return message;
    }
    next(channelName) {
        let message;
        try {
            const next = this.queues.get(channelName).whosNext();
            message = `The next in queue is ${next}.`;
        }
        catch (e) {
            message = e.message;
        }
        return message;
    }
    who(channelName) {
        let message;
        try {
            const usersInQueue = this.queues.get(channelName).getGuestList().join(", ");
            message = `The following users are in this queue: ${usersInQueue}.`;
        }
        catch (e) {
            message = e.message;
        }
        return message;
    }
    clear(channelName) {
        let message;
        try {
            this.queues.get(channelName).clear();
            message = `The queue has been cleared!`;
        }
        catch (e) {
            message = e.message;
        }
        return message;
    }
    help() {
        return "ChimaQueue:\n" +
            "For usage help, access: https://github.com/danielbertolozi/chimaqueue.\n" +
            "Available Commands: new, join, leave, next, who, clear.";
    }
}
exports.default = Chimas;
var Actions;
(function (Actions) {
    Actions["new"] = "new";
    Actions["join"] = "join";
    Actions["leave"] = "leave";
    Actions["next"] = "next";
    Actions["who"] = "who";
    Actions["clear"] = "clear";
    Actions["help"] = "help";
})(Actions || (Actions = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ2hpbWFzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL21haW4vY2hpbWFzL0NoaW1hcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLCtDQUF3QztBQUl4QyxNQUFxQixNQUFNO0lBR3pCO1FBQ0UsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLHFCQUFXLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsVUFBVSxHQUFHO1lBQ2hCLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUN2QyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDcEMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3RDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNwQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDbEMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3RDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztTQUNyQyxDQUFBO0lBQ0gsQ0FBQztJQUVNLE9BQU8sQ0FBQyxNQUFjLEVBQUUsT0FBcUI7UUFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNwQixPQUFPLHVCQUF1QixDQUFDO1NBQ2hDO1FBQ0QsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQztRQUN6QyxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDO1FBQ25DLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVPLElBQUksQ0FBQyxXQUFtQixFQUFFLFFBQWdCO1FBQ2hELElBQUksT0FBZSxDQUFDO1FBQ3BCLElBQUk7WUFDRixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDM0MsT0FBTyxHQUFHLEdBQUcsUUFBUSx3QkFBd0IsQ0FBQztTQUMvQztRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1YsT0FBTyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7U0FDckI7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNqQixDQUFDO0lBRU8sUUFBUSxDQUFDLFdBQW1CO1FBQ2xDLElBQUksT0FBZSxDQUFDO1FBQ3BCLElBQUk7WUFDRixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUNoQyxPQUFPLEdBQUcsNkJBQTZCLFdBQVcsRUFBRSxDQUFDO1NBQ3REO1FBQUMsT0FBTyxDQUFDLEVBQUU7WUFDVixPQUFPLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQztTQUNyQjtRQUNELE9BQU8sT0FBTyxDQUFDO0lBQ2pCLENBQUM7SUFFTyxLQUFLLENBQUMsV0FBbUIsRUFBRSxRQUFnQjtRQUNqRCxJQUFJLE9BQWUsQ0FBQztRQUNwQixJQUFJO1lBQ0YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3ZDLE9BQU8sR0FBRyxRQUFRLFFBQVEsc0JBQXNCLENBQUM7U0FDbEQ7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNWLE9BQU8sR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQ3JCO1FBQ0QsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVPLElBQUksQ0FBQyxXQUFtQjtRQUM5QixJQUFJLE9BQWUsQ0FBQztRQUNwQixJQUFJO1lBQ0YsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDckQsT0FBTyxHQUFHLHdCQUF3QixJQUFJLEdBQUcsQ0FBQztTQUMzQztRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1YsT0FBTyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7U0FDckI7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNqQixDQUFDO0lBRU8sR0FBRyxDQUFDLFdBQW1CO1FBQzdCLElBQUksT0FBZSxDQUFDO1FBQ3BCLElBQUk7WUFDRixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUUsT0FBTyxHQUFHLDBDQUEwQyxZQUFZLEdBQUcsQ0FBQztTQUNyRTtRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1YsT0FBTyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7U0FDckI7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNqQixDQUFDO0lBRU8sS0FBSyxDQUFDLFdBQW1CO1FBQy9CLElBQUksT0FBZSxDQUFDO1FBQ3BCLElBQUk7WUFDRixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNyQyxPQUFPLEdBQUcsNkJBQTZCLENBQUM7U0FDekM7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNWLE9BQU8sR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQ3JCO1FBQ0QsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVPLElBQUk7UUFDVixPQUFPLGVBQWU7WUFDcEIsMEVBQTBFO1lBQzFFLHlEQUF5RCxDQUFDO0lBQzlELENBQUM7Q0FDRjtBQWhHRCx5QkFnR0M7QUFFRCxJQUFLLE9BUUo7QUFSRCxXQUFLLE9BQU87SUFDVixzQkFBVyxDQUFBO0lBQ1gsd0JBQWEsQ0FBQTtJQUNiLDBCQUFlLENBQUE7SUFDZix3QkFBYSxDQUFBO0lBQ2Isc0JBQVcsQ0FBQTtJQUNYLDBCQUFlLENBQUE7SUFDZix3QkFBYSxDQUFBO0FBQ2YsQ0FBQyxFQVJJLE9BQU8sS0FBUCxPQUFPLFFBUVgifQ==